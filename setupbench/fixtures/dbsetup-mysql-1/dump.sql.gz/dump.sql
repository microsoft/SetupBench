
CREATE DATABASE IF NOT EXISTS benchmark_db;
USE benchmark_db;

CREATE TABLE IF NOT EXISTS products (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    price DECIMAL(10, 2) NOT NULL
);

INSERT INTO products (name, price) VALUES
('Widget', 19.99),
('Gadget', 29.99),
('Doohickey', 9.99);
