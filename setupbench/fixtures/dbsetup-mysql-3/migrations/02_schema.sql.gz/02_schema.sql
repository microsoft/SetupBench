
CREATE DATABASE IF NOT EXISTS benchmark_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

USE benchmark_db;

CREATE TABLE IF NOT EXISTS categories (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL
);

CREATE DEFINER=`devops`@`%` VIEW category_view AS
SELECT id, name FROM categories;

CREATE TABLE IF NOT EXISTS products (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(20) NOT NULL,
    price DECIMAL(10, 2) NOT NULL,
    category_id INT,
    FOREIGN KEY (category_id) REFERENCES categories(id)
);
