
USE benchmark_db;

INSERT INTO categories (name) VALUES
('Electronics'),
('Books'),
('Clothing');

INSERT INTO products (name, price, category_id) VALUES
('Headphones', 59.99, 1),
('Novel', 14.95, 2),
('T-shirt', 19.99, 3);
