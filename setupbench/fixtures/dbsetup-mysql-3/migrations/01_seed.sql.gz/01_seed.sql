
INSERT INTO categories (name) VALUES
('Games'), ('Music');

INSERT INTO products (name, price, category_id) VALUES
('Guitar', 199.99, 2),
('Board Game', 29.99, 1);
